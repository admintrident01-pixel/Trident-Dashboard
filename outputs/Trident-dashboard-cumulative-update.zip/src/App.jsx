import Icon from './Icon'
import TimesheetHistory from './TimesheetHistory'
import { lazy, Suspense, useCallback, useEffect, useRef, useState } from 'react'

import './App.css'
import './LogoTheme.css'
import './MyDay.css'
import './TechnicianForms.css'





import EmailSignIn from './EmailSignIn'

import ReminderDashboard from './ReminderDashboard'
import {loadSession,saveSession} from './session'
import {loadPage,canAccessPage,homePage} from './navigation'
import {myDayEnabled} from './myDayModel'
import {appointmentImport,quoteImport,transferId,savedCaptureId} from './jobImportModel'

const StockPage=lazy(()=>import('./StockPage'))
const MyDay=lazy(()=>import('./MyDay'))
const JobImport=lazy(()=>import('./JobImport'))
const WeeklyReport=lazy(()=>import('./WeeklyReport'))
const SettingsPage=lazy(()=>import('./SettingsPage'))
const VehicleChecks=lazy(()=>import('./VehicleChecks'))
const LeaveForms=lazy(()=>import('./LeaveForms'))
const TechSchedule=lazy(()=>import('./TechSchedule'))
const OfficeFiles=lazy(()=>import('./OfficeFiles'))
const OnCallRoster=lazy(()=>import('./OnCallRoster'))

const localMode=import.meta.env.DEV&&import.meta.env.VITE_LOCAL_DEVELOPMENT==='true'

const api=localMode?'http://127.0.0.1:18782':(import.meta.env.VITE_API_URL||'https://trident-quote-api-383423323438.australia-southeast1.run.app').replace(/\/$/,'')

export default function App(){

 const [session,setSession]=useState(loadSession),[error,setError]=useState(''),[document,setDocument]=useState(''),[timesheetDocument,setTimesheetDocument]=useState(''),[selectedPage,setPage]=useState(loadPage)
 const page=canAccessPage(selectedPage,session)?(selectedPage==='home'?homePage(session):selectedPage):homePage(session)
 const [timesheetOpenRequest,setTimesheetOpenRequest]=useState(null)
 const [incomingJob,setIncomingJob]=useState(null),quoteImportRef=useRef(null)
 const [savedJobId]=useState(()=>savedCaptureId(location.hash))
 const consumeIncoming=useCallback(()=>setIncomingJob(null),[])
 const [navigationMode,setNavigationMode]=useState(()=>{try{return localStorage.getItem('trident-navigation-mode')||'pinned'}catch{return 'pinned'}})
 const [navigationOpen,setNavigationOpen]=useState(false)
 const inFlightReads=useRef(new Map())
 const navigationVisible=navigationMode==='pinned'||navigationOpen
 function navigationPreference(mode){setNavigationMode(mode);setNavigationOpen(false);try{localStorage.setItem('trident-navigation-mode',mode)}catch{/* Keep this window's preference. */}}
 const [visitedPages,setVisitedPages]=useState(()=>({[loadPage()]:true}))
 const visitPage=useCallback(next=>{if(next!=='timesheet')setTimesheetOpenRequest(null);setVisitedPages(current=>current[next]?current:{...current,[next]:true});setPage(next)},[])

 useEffect(()=>saveSession(session),[session])
 useEffect(()=>{inFlightReads.current.clear()},[session?.token])
 useEffect(()=>{const titles={home:'My day',workspace:'Reminders','my-day':'My day',quotes:'Quotes','job-import':'Import job',schedule:'Tech schedule',oncall:'On call',timesheet:'Time sheet',leave:'Leave forms',reports:'Labour payables',vehicles:'Vehicle checks',stock:'Stock & assets',settings:'Settings',office:'Shared resources'};window.document.title=(titles[page]||'Home')+' · Trident Dashboard'},[page])

 useEffect(()=>{if(session)window.history.replaceState(null,'',`${location.pathname}${location.search}#${page}${page==='job-import'?(savedJobId?'?job='+savedJobId:transferId(location.hash)?'?transfer='+transferId(location.hash):''):''}`)},[page,session,savedJobId])
 useEffect(()=>{const change=()=>{const next=loadPage();if(page==='reports'&&next!==page&&window.tridentReportHasUnsavedChanges?.()&&!window.confirm('Report entries are unsaved. Leave anyway?')){window.history.replaceState(null,'',`#${page}`);return}if(page==='quotes'&&next!==page&&quoteFrame.current?.contentWindow.tridentQuoteHasUnsavedChanges?.()&&!window.confirm('Your quote has unsaved changes. Save your draft before leaving. Leave anyway?')){window.history.replaceState(null,'',`#${page}`);return}visitPage(next)};window.addEventListener('hashchange',change);return()=>window.removeEventListener('hashchange',change)},[page,visitPage])

 const timesheetFrame=useRef(null),quoteFrame=useRef(null),pendingDraft=useRef('')
 function continueTimesheetDraft(id){navigate('timesheet');pendingDraft.current=id;if(timesheetFrame.current){timesheetFrame.current.contentWindow.postMessage({type:'trident-resume-timesheet-draft',id},location.origin);pendingDraft.current='';timesheetFrame.current.scrollIntoView({block:'start',behavior:'smooth'})}}
 const [timesheetHeight,setTimesheetHeight]=useState(900)
 const [managementSection,setManagementSection]=useState('staff')

 const isAdmin=session?.role==='admin'

 const hasMyDay=myDayEnabled(session)
 const allowed=key=>key==='job-import'?canAccessPage(key,session):key==='my-day'?hasMyDay:isAdmin||['home','workspace','timesheet','leave','vehicles','schedule','oncall'].includes(key)

 const request=useCallback(async(path,init={})=>{

  const headers=new Headers(init.headers);headers.set('Authorization',`Bearer ${session?.token}`)

  // Coalesce simultaneous identical reads (for example a focus event and a
  // timer firing together). This never caches a completed response.
  const dedupeKey=(init.method||'GET').toUpperCase()==='GET'&&!init.body&&!init.signal?path:''
  const pending=dedupeKey?inFlightReads.current.get(dedupeKey):null
  if(pending)return pending
  const operation=(async()=>{
   const started=performance.now()
   const response=await fetch(api+path,{...init,headers}),data=await response.json()
   performance.measure(path.startsWith('/api/schedule')?'trident.api.schedule':'trident.api.request',{start:started,duration:performance.now()-started})

   if(response.status===401||response.status===403&&data.error==='Your account is not active. Contact an administrator.'){setSession(null);setDocument('');setTimesheetDocument('');setPage('home')}

   if(!response.ok)throw Object.assign(Error(data.error||'Unable to complete this request.'),{status:response.status})

   return {data,etag:response.headers.get('ETag')}
  })()
  if(dedupeKey){
   inFlightReads.current.set(dedupeKey,operation)
   const clear=()=>{if(inFlightReads.current.get(dedupeKey)===operation)inFlightReads.current.delete(dedupeKey)}
   operation.then(clear,clear)
  }
  return operation

 },[session])

 useEffect(()=>{

  if(!session||page!=='quotes'||document)return;let cancelled=false

  fetch('/quote-builder.html?v=20261114d',{cache:'no-store'}).then(r=>{if(!r.ok)throw Error('Unable to load the quote builder.');return r.text()}).then(html=>{

   const config=JSON.stringify({api,token:session.token,origin:location.origin}).replace(/</g,'\\u003c')

   const bridge=`<script>(()=>{const c=${config},original=window.fetch.bind(window);window.fetch=async(input,init={})=>{const url=typeof input==='string'?input:input.url;if(new URL(url,c.origin).pathname.startsWith('/api/')){const headers=new Headers(init.headers);headers.set('Authorization','Bearer '+c.token);const started=performance.now();const response=await original(c.api+new URL(url,c.origin).pathname+new URL(url,c.origin).search,{...init,headers});performance.measure('trident.api.request',{start:started,duration:performance.now()-started});if(response.status===401)parent.postMessage({type:'trident-signin-expired'},c.origin);return response;}return original(input,init);};})();</script>`

   if(!cancelled)setDocument(html.replace('<head>','<head>'+bridge))

  }).catch(e=>setError(e.message));return()=>{cancelled=true}

 },[session,page,document])

 useEffect(()=>{

  if(!session||page!=='timesheet'||timesheetDocument)return;let cancelled=false

  fetch('/timesheet.html?v=20261114c',{cache:'no-store'}).then(r=>{if(!r.ok)throw Error('Unable to load the time sheet.');return r.text()}).then(html=>{

   const config=JSON.stringify({api,token:session.token,origin:location.origin,pilot:myDayEnabled(session)}).replace(/</g,'\\u003c')

   const bridge=`<script>(()=>{const c=${config},original=window.fetch.bind(window);if(c.pilot)window.addEventListener('DOMContentLoaded',()=>document.body.classList.add('my-day-pilot'));window.fetch=async(input,init={})=>{const url=typeof input==='string'?input:input.url;if(new URL(url,c.origin).pathname.startsWith('/api/')){const headers=new Headers(init.headers);headers.set('Authorization','Bearer '+c.token);const started=performance.now();const response=await original(c.api+new URL(url,c.origin).pathname+new URL(url,c.origin).search,{...init,headers});performance.measure('trident.api.request',{start:started,duration:performance.now()-started});if(response.status===401)parent.postMessage({type:'trident-signin-expired'},c.origin);return response;}return original(input,init);};})();</script>`

   if(!cancelled)setTimesheetDocument(html.replace('<head>','<head>'+bridge))

  }).catch(e=>setError(e.message));return()=>{cancelled=true}

 },[session,page,timesheetDocument])

 useEffect(()=>{const handler=e=>{if(e.origin===location.origin&&e.data?.type==='trident-signin-expired'){setSession(null);setDocument('');setTimesheetDocument('');setPage('home');setError('Your session expired. Sign in again.')}};window.addEventListener('message',handler);return()=>window.removeEventListener('message',handler)},[])

 useEffect(()=>{const listener=e=>{if(e.origin===location.origin&&e.source===timesheetFrame.current?.contentWindow&&e.data?.type==='trident-timesheet-height'&&Number.isFinite(e.data.height)&&e.data.height>0&&e.data.height<20000)setTimesheetHeight(e.data.height);if(e.origin===location.origin&&e.source===timesheetFrame.current?.contentWindow&&e.data?.type==='trident-timesheets-updated')window.dispatchEvent(new Event('trident-timesheets-updated'));if(e.origin===location.origin&&e.source===timesheetFrame.current?.contentWindow&&e.data?.type==='trident-open-submitted-timesheet'&&typeof e.data.id==='string')setTimesheetOpenRequest({id:e.data.id,nonce:Date.now()})};window.addEventListener('message',listener);return()=>window.removeEventListener('message',listener)},[])
 useEffect(()=>{if(page==='timesheet'&&timesheetDocument)timesheetFrame.current?.contentWindow.postMessage({type:'trident-leave-updated'},location.origin)},[page,timesheetDocument])

 useEffect(()=>{const refresh=()=>quoteFrame.current?.contentWindow.postMessage({type:'trident-quote-settings-updated'},location.origin);window.addEventListener('trident-settings-saved',refresh);return()=>window.removeEventListener('trident-settings-saved',refresh)},[])

 useEffect(()=>{

  if(!session)return

  let cancelled=false,checking=false,lastCheck=0
  const check=async()=>{if(cancelled||checking||window.document.hidden||Date.now()-lastCheck<30000)return;checking=true;lastCheck=Date.now();try{const r=await fetch(api+'/api/session',{headers:{Authorization:'Bearer '+session.token}}),d=await r.json();if(cancelled)return;if(r.status===401||r.status===403){setSession(null);setDocument('');setTimesheetDocument('');setPage('home');return}if(!r.ok)return;if(d.role!==session.role||d.technician!==session.technician){setSession({...session,...d,token:session.token});setDocument('');setTimesheetDocument('')}}catch{/* Keep the session through temporary connection failures. */}finally{checking=false}}
  check()
  const resume=()=>{if(!window.document.hidden)check()}
  const timer=setInterval(resume,300000)
  window.document.addEventListener('visibilitychange',resume)

  return()=>{cancelled=true;clearInterval(timer);window.document.removeEventListener('visibilitychange',resume)}

 },[session])

 const openLocal=async()=>{try{setError('');const r=await fetch(`${api}/api/dev-session`);const data=await r.json();if(!r.ok)throw Error(data.error||'Start the local development server first.');setSession(data)}catch(e){setError(e.message)}}

 const navigate=next=>{if(next===page)return;if(page==='reports'&&next!==page&&window.tridentReportHasUnsavedChanges?.()&&!window.confirm('Report entries are unsaved. Save them before leaving. Leave anyway?'))return;if(page==='quotes'&&next!==page&&quoteFrame.current?.contentWindow.tridentQuoteHasUnsavedChanges?.()&&!window.confirm('Your quote has unsaved changes. Save your draft before leaving. Leave anyway?'))return;visitPage(next);window.scrollTo({top:0,behavior:'instant'})}
 useEffect(()=>{const warn=e=>{if(timesheetFrame.current?.contentWindow.tridentTimesheetHasUnsavedChanges?.()){e.preventDefault();e.returnValue=''}};window.addEventListener('beforeunload',warn);return()=>window.removeEventListener('beforeunload',warn)},[])
 function importAppointment(job,notes,allocation={}){if(!canAccessPage('job-import',session))return;setIncomingJob({id:job.transferId,fields:{...appointmentImport(job,notes),jobImportId:allocation.jobImportId||''}});navigate('schedule')}
 function reviewImportedJob(id){if(!canAccessPage('job-import',session))return;window.open(location.pathname+'#job-import?job='+encodeURIComponent(id),'_blank','noopener')}
 function sendQuoteImport(){if(!quoteFrame.current)return;const allowed=canAccessPage('job-import',session);quoteFrame.current.contentWindow.postMessage({type:'trident-job-import-permission',allowed},location.origin);if(allowed&&quoteImportRef.current)quoteFrame.current.contentWindow.postMessage({type:'trident-import-quote',...quoteImportRef.current},location.origin)}
 function importQuote(job,notes,allocation={}){if(!canAccessPage('job-import',session))return;quoteImportRef.current={id:crypto.randomUUID(),fields:quoteImport(job,notes,allocation.quoteFields,allocation.quoteMappings),allocation:{...allocation,jobNumber:job.source.jobNumber,recordId:job.source.recordId}};navigate('quotes');sendQuoteImport()}
 useEffect(()=>{const receive=e=>{if(e.origin!==location.origin||e.source!==quoteFrame.current?.contentWindow)return;if(e.data?.type==='trident-quote-import-ready'){const allowed=canAccessPage('job-import',session);quoteFrame.current.contentWindow.postMessage({type:'trident-job-import-permission',allowed},location.origin);if(allowed&&quoteImportRef.current)quoteFrame.current.contentWindow.postMessage({type:'trident-import-quote',...quoteImportRef.current},location.origin);}if(e.data?.type==='trident-quote-imported'&&e.data.id===quoteImportRef.current?.id){if(e.data.accepted)quoteImportRef.current=null;else setError(e.data.error||'The existing quote was kept. Return to Import job to try again.')}};window.addEventListener('message',receive);return()=>window.removeEventListener('message',receive)},[session])
 const signOut=async()=>{if(timesheetFrame.current?.contentWindow.tridentTimesheetHasUnsavedChanges?.()&&!window.confirm('Your time sheet has unsaved changes. Save a draft before signing out. Sign out anyway?'))return;if(window.tridentReportHasUnsavedChanges?.()&&!window.confirm('Report entries are unsaved. Sign out anyway?'))return;if(quoteFrame.current?.contentWindow.tridentQuoteHasUnsavedChanges?.()&&!window.confirm('Your quote has unsaved changes. Save your draft before signing out. Sign out anyway?'))return;try{await request('/api/auth/logout',{method:'POST'})}catch{/* The browser session is still cleared on a failed sign-out. */}setSession(null);setDocument('');setTimesheetDocument('');setPage('home');setError('')}

 if(!api||api.includes('YOUR-'))return <main className="signin"><h1>Trident Dashboard</h1><p>Online setup is not finished. Configure the API address, then rebuild the website.</p></main>

 return session?<div className={`workspace${localMode?' is-local':''}${navigationVisible?'':' navigation-hidden'}${hasMyDay?' my-day-pilot':''}${['timesheet','vehicles','leave'].includes(page)?' technician-page':''}`}>

  <a className="skip-content" href="#workspace-content" onClick={e=>{e.preventDefault();window.document.getElementById('workspace-content')?.focus()}}>Skip to page content</a>{!navigationVisible&&<div className="portal-navigation-reveal"><button aria-label="Show navigation" onClick={()=>setNavigationOpen(true)}><Icon name="menu" size={13}/>Show navigation</button></div>}<header className="portal-header" hidden={!navigationVisible}>

   <button className="portal-brand" aria-label="Trident home" onClick={()=>navigate(homePage(session))}><img src="/trident-logo.png" alt="Trident Community Equipment"/></button>

   <nav aria-label="Main navigation">{[['my-day','My day'],['quotes','Quotes'],['schedule','Tech schedule'],['oncall','On call'],['timesheet','Time sheet'],['leave','Leave forms'],['reports','Labour payables'],['vehicles','Vehicle checks'],['stock','Stock'],['settings','Settings'],['office','Shared resources'],['workspace','Reminders']].filter(([key])=>allowed(key)).map(([key,name])=><button key={key} aria-current={page===key?'page':undefined} onClick={()=>navigate(key)}>{name}</button>)}</nav>

   <div className="portal-account"><span>{session.email} · {isAdmin?'Admin':'Technician'}</span><button className="portal-pin" aria-label={navigationMode==='pinned'?'Unpin navigation':'Pin navigation'} aria-pressed={navigationMode==='pinned'} title={navigationMode==='pinned'?'Unpin navigation':'Pin navigation'} onClick={()=>navigationPreference(navigationMode==='pinned'?'hidden':'pinned')}><Icon name={navigationMode==='pinned'?'custom-pin-off':'custom-pin'} size={16}/><span>{navigationMode==='pinned'?'Unpin':'Pin'}</span></button><button className="portal-hide" aria-label="Hide navigation" title="Hide navigation" onClick={()=>navigationPreference('hidden')}><Icon name="chevron-up" size={14}/></button><button onClick={signOut}>Sign out</button></div>

  </header>

  {localMode&&<div className="development-notice">Local development · Changes are saved on this computer.</div>}

  {error&&<p role="alert">{error}</p>}

  <Suspense fallback={<p className="module-loading" role="status">Opening page…</p>}><div id="workspace-content" tabIndex={-1}>
  {page==='workspace'&&<main className="portal-home">

   <div className="home-intro"><h1>Reminders</h1><p>Upcoming tasks and due dates.</p></div>
   {isAdmin?<ReminderDashboard request={request}/>:<p>Your due tasks are listed on <button className="reminder-my-day-link" onClick={()=>navigate('my-day')}>My day</button>.</p>}
  </main>}

  {canAccessPage('job-import',session)&&(page==='job-import'||visitedPages['job-import'])&&<section hidden={page!=='job-import'}><JobImport request={request} savedJobId={savedJobId} onAppointment={importAppointment} onQuote={importQuote}/></section>}
  {hasMyDay&&page==='my-day'&&<MyDay request={request} session={session} onNavigate={navigate}>{isAdmin&&<ReminderDashboard request={request}/>}</MyDay>}
  {hasMyDay&&['timesheet','leave','vehicles'].includes(page)&&<div className="mobile-my-day-return"><button type="button" aria-label="Back to My day" onClick={()=>navigate('my-day')}><Icon name="arrow-left" size={16}/>My day</button></div>}
  {page==='quotes'&&!document&&<p className="module-loading" role="status">Loading your quotes…</p>}

  {document&&<section className="quote-module" hidden={page!=='quotes'} aria-label="Quotes"><iframe ref={quoteFrame} title="Trident quote builder" onLoad={sendQuoteImport} srcDoc={document}/></section>}

  {page==='timesheet'&&!timesheetDocument&&<p className="module-loading" role="status">Loading your time sheet…</p>}

  {timesheetDocument&&<section className="quote-module timesheet-module" hidden={page!=='timesheet'} aria-label="Time sheet"><iframe ref={timesheetFrame} title="Trident time sheet" onLoad={()=>{if(pendingDraft.current){timesheetFrame.current.contentWindow.postMessage({type:'trident-resume-timesheet-draft',id:pendingDraft.current},location.origin);pendingDraft.current=''}}} style={{height:timesheetHeight}} srcDoc={timesheetDocument}/>{page==='timesheet'&&<TimesheetHistory openRequest={timesheetOpenRequest} request={request} isAdmin={isAdmin} onContinueDraft={continueTimesheetDraft}/>}</section>}

  {(page==='oncall'||visitedPages.oncall)&&<section hidden={page!=='oncall'}><OnCallRoster request={request}/></section>}

  {(page==='leave'||visitedPages.leave)&&<section hidden={page!=='leave'}><LeaveForms technician={session.technician} isAdmin={isAdmin} request={request} active={page==='leave'} onChanged={()=>{timesheetFrame.current?.contentWindow.postMessage({type:'trident-leave-updated'},location.origin);window.dispatchEvent(new Event('trident-leave-updated'))}}/></section>}

  {page==='office'&&<Suspense fallback={<p className="module-loading" role="status">Opening shared resources…</p>}><OfficeFiles request={request} isAdmin={isAdmin}/></Suspense>}
  {isAdmin&&page==='stock'&&<StockPage request={request}/>}
  {isAdmin&&page==='reports'&&<WeeklyReport request={request}/>}
  {(page==='schedule'||visitedPages.schedule)&&<section hidden={page!=='schedule'}><TechSchedule request={request} isAdmin={isAdmin} active={page==='schedule'} draftOwner={session.email} incomingJob={incomingJob} onIncomingConsumed={consumeIncoming} onReviewImportedJob={canAccessPage('job-import',session)?reviewImportedJob:undefined}/></section>}

  {(page==='vehicles'||visitedPages.vehicles)&&<section hidden={page!=='vehicles'}><VehicleChecks onManage={()=>{setManagementSection('fleet');navigate('settings')}} isAdmin={isAdmin} technician={session.technician} request={request} active={page==='vehicles'}/></section>}

  {isAdmin&&<section hidden={page!=='settings'}>{page==='settings'&&<SettingsPage canImportJobs={canAccessPage('job-import',session)} initialManagementSection={managementSection} request={request} onSaved={()=>{timesheetFrame.current?.contentWindow.postMessage({type:'trident-staff-updated'},location.origin);window.dispatchEvent(new Event('trident-settings-saved'))}}/>}</section>}

 </div>
 </Suspense>
 </div>:<EmailSignIn api={api} localMode={localMode} onLocal={openLocal} onSignedIn={setSession}/>

}

